Step 1
Read through all steps then go to https://desktop.github.com/download/    download GitHub Desktop

Step 2
go to https://github.com/ and make an account

Step 3 
Go to https://pages.github.com/  go to this link and follow instructions on this page when it asks you what git client your using select GitHub Desktop. You can ignore everything after step 2 on the web page.
*****IMPORTANT********** when you create the repository make sure you DON'T add a gitignore file or a read me file, and DON'T select any kind of license as this would cause conflicts and make the repository open source!!!! 

Step 4 
When you have the repository selected in the GitHub Desktop application use the key binds (ctrl+shift+f) this should open the repository root folder
this is where you place the extracted Build folder and the index.html and license files dont include this instruction file.

Step 5 
Now head back to the GitHub Desktop application and you should see those files listed on the left side and below them you will see a text box in the smaller of the two text boxes type Initial_Commit and then click the blue commit to main button.
And then click push to origin button.

Step 6 
Wait a 5 mins and then open a browser and head to https://YourGitHubUserName.github.io. the PFP build should now be fully funtioning ready to add to the website  



